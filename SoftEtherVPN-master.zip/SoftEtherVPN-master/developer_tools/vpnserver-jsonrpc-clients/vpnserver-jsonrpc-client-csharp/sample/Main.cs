﻿// SoftEther VPN Server JSON-RPC Stub code for C#
// 
// Program.cs - The Main() entry point
//
// Automatically generated at 2023-05-10 14:43:37 by vpnserver-jsonrpc-codegen
//
// Licensed under the Apache License 2.0
// Copyright (c) 2014-2023 SoftEther VPN Project

class Program
{
    static void Main(string[] args)
    {
        VPNRPCTest test = new VPNRPCTest();
        test.Test_All();
    }
}
