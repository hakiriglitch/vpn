#ifndef CRYPTO_TYPES_H
#define CRYPTO_TYPES_H

typedef enum CRYPTO_KEY_TYPE CRYPTO_KEY_TYPE;

typedef struct CRYPTO_KEY_RAW CRYPTO_KEY_RAW;

#endif
