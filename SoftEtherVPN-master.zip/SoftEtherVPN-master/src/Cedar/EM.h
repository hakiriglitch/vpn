// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// EM.h
// Header of EM.c

#ifndef	EM_H
#define	EM_H

// Public function
void EMExec();

#endif	// EM_H


