// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// SM.h
// Header of SM.c

#ifndef	SM_H
#define	SM_H

void SMExec();

#endif	// SM_H


