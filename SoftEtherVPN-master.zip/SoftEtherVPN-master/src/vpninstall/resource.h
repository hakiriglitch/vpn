//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by vpninstall.rc
//
#define IDI_ICON1                       101
#define IDI_MAIN                        101
#define IDS_STRING102                   102
#define IDS_TITLE                       102
#define IDS_FONT                        103
#define IDS_FONT_SIZE                   104
#define IDS_INF_LOAD_FAILED             105
#define IDS_DIFF_CPU                    106
#define IDS_INSTANCE_EXISTS             107
#define IDS_BAD_OS                      108
#define IDS_CPU_NOT_SUPPORTED           109
#define IDS_DOWNLOADING                 110
#define IDS_DOWNLOADSTART               111
#define IDS_TEMP_ERROR                  112
#define IDS_DOWNLOAD_ERROR              113
#define IDS_DOWNLOADING2                114
#define IDS_DOWNLOADING3                115
#define IDS_INSTALLSTART                116
#define IDS_INSTALLSTART_ERROR          117
#define IDS_SECURITY_ERROR              118
#define IDS_SIGN_WARNING                119
#define IDS_SIGN_WARNING_TITLE          120
#define IDS_TITLE_VPNSMGR               121
#define IDS_VPNSMGR_EXEC_ERROR          122
#define IDS_DLG_TITLE                   123
#define IDS_INSTALL_DLG__STATUS_INIT    124
#define IDS_INSTALL_CANCEL              125
#define IDS_EULA_NOTICE1                126
#define IDS_EULA_NOTICE2                127
#define IDS_EULA_NOTICE3                128
#define IDS_EULA_AGREE                  129
#define IDS_EULA_DISAGREE               130
#define S_TITLE                         1001
#define P_PROGRESS                      1002
#define S_STATUS                        1003
#define S_SIZEINFO                      1005
#define E_EULA                          1006
#define S_BOLD                          1008
#define S_EULA_NOTICE1                  1009
#define S_EULA_NOTICE3                  1010
#define IDS_TITLE_EN                    1102
#define IDS_FONT_EN                     1103
#define IDS_FONT_SIZE_EN                1104
#define IDS_INF_LOAD_FAILED_EN          1105
#define IDS_DIFF_CPU_EN                 1106
#define IDS_INSTANCE_EXISTS_EN          1107
#define IDS_BAD_OS_EN                   1108
#define IDS_CPU_NOT_SUPPORTED_EN        1109
#define IDS_DOWNLOADING_EN              1110
#define IDS_DOWNLOADSTART_EN            1111
#define IDS_TEMP_ERROR_EN               1112
#define IDS_DOWNLOAD_ERROR_EN           1113
#define IDS_DOWNLOADING2_EN             1114
#define IDS_DOWNLOADING3_EN             1115
#define IDS_INSTALLSTART_EN             1116
#define IDS_INSTALLSTART_ERROR_EN       1117
#define IDS_SECURITY_ERROR_EN           1118
#define IDS_SIGN_WARNING_EN             1119
#define IDS_SIGN_WARNING_TITLE_EN       1120
#define IDS_TITLE_VPNSMGR_EN            1121
#define IDS_VPNSMGR_EXEC_ERROR_EN       1122
#define IDS_DLG_TITLE_EN                1123
#define IDS_INSTALL_DLG__STATUS_INIT_EN 1124
#define IDS_INSTALL_CANCEL_EN           1125
#define IDS_EULA_NOTICE1_EN             1126
#define IDS_EULA_NOTICE2_EN             1127
#define IDS_EULA_NOTICE3_EN             1128
#define IDS_EULA_AGREE_EN               1129
#define IDS_EULA_DISAGREE_EN            1130
#define D_INSTALL                       2007
#define D_EULA                          2008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        123
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
