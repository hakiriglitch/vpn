#!/bin/sh

set -eux

./build/vpncmd /tools /cmd:check
