This project is no longer hosted here. Come find us at [our gitlab
repository](https://gitlab.torproject.org/tpo/core/tor) instead.

## About

Tor protects your privacy on the internet by hiding the connection between
your Internet address and the services you use. We believe Tor is reasonably
secure, but please ensure you read the instructions and configure it properly.

## Resources

Home page:

- https://www.torproject.org/

Download new versions:

- https://www.torproject.org/download/download.html

Documentation, including links to installation and setup instructions:

- https://www.torproject.org/docs/documentation.html

Frequently Asked Questions:

- https://www.torproject.org/docs/faq.html

